<div class="MainPage">
    <div>
        Notifications
    </div>
</div>


<script>

</script>
</body>

</html>