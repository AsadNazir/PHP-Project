<?php

echo "<h1>Error 404 not Found</h1>";

?>